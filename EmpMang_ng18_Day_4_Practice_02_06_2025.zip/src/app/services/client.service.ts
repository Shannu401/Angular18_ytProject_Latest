import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APIResponseModel } from '../model/interface/role';
import { environment } from '../../environments/environment';
import { Client } from '../model/class/client';
import { Constant } from '../constant/Constants';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private hc:HttpClient) { }

  getAllClients(): Observable<APIResponseModel>{
    return this.hc.get<APIResponseModel>(environment.API_URL + Constant.API_METHOD.GET_ALL_CLIENT);
  }
  addUpdateClient(obj:Client): Observable<APIResponseModel>{
    return this.hc.post<APIResponseModel>(environment.API_URL + "AddUpdateClient", obj);
  }
  deleteClient(id:number): Observable<APIResponseModel>{
    return this.hc.delete<APIResponseModel>(environment.API_URL +"DeleteClientByClientId?clientId="+id);
  }

  getAllEmployee():Observable<APIResponseModel>{
    return this.hc.get<APIResponseModel>(environment.API_URL + Constant.API_METHOD.GET_ALL_EMP);
  }
  addUpdateClientProject(obj: Client): Observable<APIResponseModel>{
    return this.hc.post<APIResponseModel>(environment.API_URL + "AddUpdateClientProject", obj);
  }

  getAllUsers():Observable<any> {
    return this.hc.get<any>("https://jsonplaceholder.typicode.com/users");
  }

  getAllClientProjects(): Observable<APIResponseModel> {
    return this.hc.get<APIResponseModel>(environment.API_URL + Constant.API_METHOD.GET_ALL_PROJECTS);
  }
}

import { HttpClient } from '@angular/common/http';
import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { APIResponseModel, IRole } from '../../model/interface/role';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-roles',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './roles.component.html',
  styleUrl: './roles.component.css'
})
export class RolesComponent implements OnInit {
  //string, number, boolean, null, undefined, array, object, date

  // firstName : string = "Angular Tutorial";
  // angularVersion = "Version 18";
  // version: number = 18;
  // isActive: boolean = false;
  // currentDate: Date = new Date()
  // inputType: string = "button";
  // selectedState: string = "AP";

  // showWelcomeAlert(){
  //   alert("Welcome to the Angulat 18 Tutorial!!!");
  // }
  // showMsg(msg:string){
  //   alert(msg);
  // }


  // roleList: IRole[] = [];
  // hc = inject(HttpClient);
  // //constructor(private hc:HttpClient){}

  // ngOnInit(): void {
  //   this.getAllRoles();
  // }

  // getAllRoles(){
  //   this.hc.get("https://freeapi.miniprojectideas.com/api/ClientStrive/GetAllRoles").subscribe((res:any)=> {
  //     this.roleList = res.data;
  //   })
  // }


  roleList: IRole[] = [];
  hc = inject(HttpClient);
  //constructor(private hc:HttpClient){}

  ngOnInit(): void {
    this.getAllRoles();
  }

  getAllRoles(){
    this.hc.get<APIResponseModel>("https://freeapi.miniprojectideas.com/api/ClientStrive/GetAllRoles").subscribe((res:APIResponseModel)=> {
      this.roleList = res.data;
    })
  }

}

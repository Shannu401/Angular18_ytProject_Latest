import { Component, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { APIResponseModel, IClientProject, IEmployee } from '../../model/interface/role';
import { ClientService } from '../../services/client.service';
import { Client } from '../../model/class/client';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-client-project',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './client-project.component.html',
  styleUrl: './client-project.component.css'
})
export class ClientProjectComponent implements  OnInit {

  projectForm: FormGroup = new FormGroup({
    clientProjectId: new FormControl(0),
    projectName: new FormControl("", [Validators.required, Validators.minLength(4)]),
    startDate: new FormControl(""),
    expectedEndDate: new FormControl(""),
    completedDate: new FormControl(""),
    contactPersonContactNo: new FormControl(""),
    contactPerson: new FormControl(""),
    leadByEmpId: new FormControl(""),
    totalEmpWorking: new FormControl(""),
    projectCost: new FormControl(""),
    projectDetails: new FormControl(""),
    contactPersonEmailId: new FormControl(""),
    clientId: new FormControl("")
  });

  clientService = inject(ClientService);
  employeeList: IEmployee[] = [];
  clientList: Client[] = [];

  firstName  = signal("Angular 18");
  projectList = signal<IClientProject[]>([]);

  ngOnInit(): void {
    this.getAllClients();
    this.getAllEmployee();
     //const name = this.firstName();
     this.getAllClientProjects();
  }
  changeFName(){
    this.firstName.set("React Js");
  }

  getAllEmployee() {
    this.clientService.getAllEmployee().subscribe((res:APIResponseModel)=> {
      this.employeeList = res.data;
    })
  }
  getAllClients() {
    this.clientService.getAllClients().subscribe((res:APIResponseModel)=> {
      this.clientList = res.data;
    })
  }
  saveProject() {
    const formValue = this.projectForm.value;
    debugger;
    this.clientService.addUpdateClientProject(formValue).subscribe((res:APIResponseModel)=>{
      if(res.result){
        alert('Project Created Successfully!!!')
      } else {
        alert(res.message);
      }
    })
  }

  getAllClientProjects() {
    this.clientService.getAllClientProjects().subscribe((res: APIResponseModel)=> {
      this.projectList.set(res.data);
    })
  }
}

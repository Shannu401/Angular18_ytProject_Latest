import { Component, inject, OnInit } from '@angular/core';
import { MasterService } from '../../services/master.service';
import { APIResponseModel, IDesignation } from '../../model/interface/role';

@Component({
  selector: 'app-designation',
  standalone: true,
  imports: [],
  templateUrl: './designation.component.html',
  styleUrl: './designation.component.css'
})
export class DesignationComponent implements  OnInit {

  isLoader = true;
  designationList: IDesignation[] = [];
  masterService = inject(MasterService);
  
  ngOnInit(): void {
    this.masterService.getAllDesignation().subscribe((res:APIResponseModel)=>{
      this.designationList = res.data;
      this.isLoader = false;
    }, error=> {
      alert("API Error / Network down!");
      this.isLoader = false;
    })
  }
}

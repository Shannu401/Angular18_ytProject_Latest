import { Component, inject, OnInit } from '@angular/core';
import { Client } from '../../model/class/client';
import { FormsModule } from '@angular/forms';
import { ClientService } from '../../services/client.service';
import { APIResponseModel } from '../../model/interface/role';
import { AsyncPipe, CommonModule, DatePipe, JsonPipe, UpperCasePipe } from '@angular/common';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-client',
  standalone: true,
  imports: [FormsModule, CommonModule, UpperCasePipe, DatePipe, JsonPipe, AsyncPipe],
  templateUrl: './client.component.html',
  styleUrl: './client.component.css'
})
export class ClientComponent implements OnInit{

  currentDate: Date = new Date();

  clientObj: Client = new Client();
  clientList: Client[] = [];
  clientService = inject(ClientService);
  userList$: Observable<any> = new Observable<any>;

  ngOnInit(): void {
    this.loadClient();
    this.userList$ = this.clientService.getAllUsers();
  }

  loadClient(){
    this.clientService.getAllClients().subscribe((res:APIResponseModel)=>{
      this.clientList = res.data;
    })
  }

  onSaveClient(){
    debugger;
    this.clientService.addUpdateClient(this.clientObj).subscribe((res:APIResponseModel)=> {
      if(res.result){
        alert("Client Creates Successfully!!!!!");
        this.loadClient();
        this.clientObj = new Client();
      }
      else {
        alert(res.message);
      }
    })
  }

  onDelete(id:number){
    const isDelete = confirm("Are you sure!! want to delete?");
    if(isDelete){
      console.log(id);
      this.clientService.deleteClient(id).subscribe((res:APIResponseModel)=>{
        if(res.result){
          alert("Client deleted successfully!!!");
          this.loadClient();
        }
        else {
          alert(res.message);
        }
      })
    }
  }

  onEdit(data:Client){
    this.clientObj = data;
  }

  resetClient(){
    this.clientObj = new Client();
    this.loadClient();
  }
}
